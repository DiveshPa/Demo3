using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Repositories.Interface;
using Repositories.Models;

namespace MVC.Controllers
{
    // [Route("[controller]")]
    public class ItemController : Controller
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly IItemRepository _itemRepository;
       
        public ItemController(IItemRepository itemRepository,IHttpContextAccessor httpContextAccessor)
        {
           _httpContextAccessor=httpContextAccessor;
           _itemRepository=itemRepository;
        }

        public IActionResult Index()
        {
            
            return View();
        }
         public IActionResult GetAll()
        {

            return Json(_itemRepository.GetAllItems());
        }

         public IActionResult IndexCustomer()
        {
            string userrole=HttpContext.Session.GetString("role");
            if(userrole==null){
                return RedirectToAction("Login","Item");
            }
             List<tblItem> items=_itemRepository.GetAllItemsCustomer();
            return View(items);
        }

        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(tblUser user)
        {
            _itemRepository.Login(user.c_email,user.c_password);

            var session=_httpContextAccessor.HttpContext.Session;

            string userrole=HttpContext.Session.GetString("role");

            int userid=HttpContext.Session.GetInt32("userid")??0;

             
           if(!string.IsNullOrEmpty(userrole))
           {
            return Json(new{id=userid,role=userrole});
           }

           return Json(new{message="Login Unsucessfull"});
        }

        public IActionResult Create()
        {
            return View();
        }
        static string file = "";
        [HttpPost]
        public IActionResult Create(tblItem product)
        {
            product.c_itemimage = file;
           _itemRepository.AddItem(product);
            return Json("Index");


        }

        [HttpPost]
        public IActionResult UploadPhoto(tblItem product)
        {
            if (product.Profile != null)
            {
                string filename = product.Profile.FileName;
                string filepath = Path.Combine("D:\\OfflineKenoShoopingSystem\\MVC\\wwwroot", "uploads", filename);

                using (var stream = new FileStream(filepath, FileMode.Create))
                {

                    product.Profile.CopyTo(stream);
                }

                file = filename;

            }

            return Json("a");
        }
        public IActionResult Edit(int id)
        {
            var model = _itemRepository.GetOneItem(id);
            return View(model);
        }
        [HttpPost]
        public IActionResult Edit(tblItem product)
        {
            product.c_itemimage = file;
         _itemRepository.UpdateItem(product);
            return Json("Index");


        }
        [HttpDelete]
        public IActionResult Delete(tblItem product)
        {
          _itemRepository.Delete(product);
            return RedirectToAction("Index");
        }
          public IActionResult GetAllCategories()
        {
            return Json(_itemRepository.GetAllcategories());
        }

         [HttpGet]
        public IActionResult GetItemData(int id)
        {
    
            var emp = _itemRepository.GetOneItemCustomer(id);
             Console.WriteLine(id);
            return Json(emp);
        }

        public IActionResult Purchase(int id){
            string userrole=HttpContext.Session.GetString("role");
            if(userrole==null){
                return RedirectToAction("Login","Item");
            }
            var item=_itemRepository.GetOneItemCustomer(id);
            return View(item);
        }

       


         [HttpPost]
       public IActionResult Purchase(tblItem item){
            string userrole=HttpContext.Session.GetString("role");
            if(userrole==null){
                return RedirectToAction("Login","Item");
            }
            _itemRepository.UpdateItemCustomer(item);
              return Json(new { success = true});
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}