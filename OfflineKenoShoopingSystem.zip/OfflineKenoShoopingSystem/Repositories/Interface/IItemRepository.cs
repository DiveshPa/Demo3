using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Npgsql;
using Repositories.Models;

namespace Repositories.Interface
{
    public interface IItemRepository
    {
        public void Login(string email, string password);

        public void AddItem(tblItem item);

        public void UpdateItem(tblItem item);

        public List<tblItem> GetAllItems();

        public tblItem GetOneItem(int id);

        public void Delete(tblItem product);
        public List<tblCategory> GetAllcategories();

         public List<tblItem> GetAllItemsCustomer();

          public tblItem GetOneItemCustomer(int id);

           public void UpdateItemCustomer(tblItem item);



    }
}