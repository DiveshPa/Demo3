using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace Repositories.Models
{
    public class tblItem
    {
        public int c_itemid{get;set;}

        public int c_catid{get;set;}

        public string c_itemname{get;set;}

        public string c_itemimage{get;set;}

        public IFormFile Profile{get;set;}

        public int c_itemcost{get;set;}

        public int c_total{get;set;}

        public int c_availablestock{get;set;}

        public int c_initialstock{get;set;}

         public string? categoryname{get;set;}

         public int c_quantity{get;set;}

        

    }
}