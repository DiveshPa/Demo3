using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Repositories.Models
{
    public class tblCategory
    {
        public int c_categoryid{get;set;}

        public string? c_categoryname{get;set;}
    }
}