using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Npgsql;
using Repositories.Interface;
using Repositories.Models;

namespace Repositories.Implementation
{
    public class ItemRepository:IItemRepository
    {
        private NpgsqlConnection _conn;

        private IHttpContextAccessor _httpContextAccessor;

        public ItemRepository(IConfiguration config, IHttpContextAccessor httpContextAccessor)
        {
            _conn = new NpgsqlConnection(config.GetConnectionString("pgconn"));
            _httpContextAccessor = httpContextAccessor;
        }

        public void Login(string email, string password)
        {
            try
            {
                _conn.Open();

                using var cmd = new NpgsqlCommand("select c_regid,c_role,c_email,c_password from t_register where c_email=@email and c_password=@password", _conn);

                cmd.Parameters.AddWithValue("@email", email);
                cmd.Parameters.AddWithValue("@password", password);


                var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    var session = _httpContextAccessor.HttpContext.Session;
                    session.SetString("role", reader["c_role"].ToString());
                    session.SetInt32("userid", (int)reader["c_regid"]);
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                _conn.Close();
            }
        }
        public void AddItem(tblItem item)
        {
            try
            {
                _conn.Open();

                using var cmd = new NpgsqlCommand("insert into t_item(c_itemname,c_catid,c_itemimage,c_itemcost,c_initialstock,c_availablestock) values(@name,@categoryid,@image,@cost,@initialstock,@availablestock)", _conn);

                cmd.Parameters.AddWithValue("@name", item.c_itemname);
                cmd.Parameters.AddWithValue("@categoryid", item.c_catid);
                cmd.Parameters.AddWithValue("@image", item.c_itemimage);
                cmd.Parameters.AddWithValue("@cost", item.c_itemcost);
                cmd.Parameters.AddWithValue("@initialstock", item.c_initialstock);
                cmd.Parameters.AddWithValue("@availablestock", item.c_availablestock);

                cmd.ExecuteNonQuery();

                _conn.Close();



            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                _conn.Close();
            }


        }
        public void UpdateItem(tblItem item)
        {
            try
            {

                _conn.Open();

                using var cmd = new NpgsqlCommand("update t_item set c_itemname=@name,c_catid=@categoryid,c_itemimage=@image,c_itemcost=@cost,c_initialstock=@initialstock,c_availablestock=@availablestock where c_itemid=@id", _conn);
                cmd.Parameters.AddWithValue("@id", item.c_itemid);
                cmd.Parameters.AddWithValue("@name", item.c_itemname);
                cmd.Parameters.AddWithValue("@categoryid", item.c_catid);
                cmd.Parameters.AddWithValue("@image", item.c_itemimage);
                cmd.Parameters.AddWithValue("@cost", item.c_itemcost);
                cmd.Parameters.AddWithValue("@initialstock", item.c_initialstock);
                cmd.Parameters.AddWithValue("@availablestock", item.c_availablestock);

                cmd.ExecuteNonQuery();

                _conn.Close();


            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                _conn.Close();
            }
        }
        public List<tblItem> GetAllItems()
        {

            var items = new List<tblItem>();
            using (var conn = new NpgsqlConnection("Host=localhost;Username=postgres;Password=Divesh@007;Database=OfflineExamPrac;"))
            {
            try
            {
                conn.Open();

                using var cmd = new NpgsqlCommand("select i.c_itemid,i.c_itemname,i.c_itemimage,i.c_initialstock,i.c_availablestock,i.c_itemcost, d.c_categoryname,i.c_catid from t_item i inner join t_category d on d.c_categoryid=i.c_catid;", conn);

                var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    var item = new tblItem
                    {
                        c_itemid = Convert.ToInt32(reader["c_itemid"]),
                         c_catid = Convert.ToInt32(reader["c_catid"]),
                        c_initialstock = Convert.ToInt32(reader["c_initialstock"]),
                        c_availablestock = Convert.ToInt32(reader["c_availablestock"]),
                        c_itemcost = Convert.ToInt32(reader["c_itemcost"]),
                        c_itemimage = reader["c_itemimage"].ToString(),
                        c_itemname = reader["c_itemname"].ToString(),
                        categoryname = reader["c_categoryname"].ToString(),


                    };
                    items.Add(item);
                }

            }

            catch (Exception e)
            {

            }
            finally
            {
                conn.Close();
            }
            }
            return items;


        }

        public tblItem GetOneItem(int id)
        {
            var item = new tblItem();
            using (var conn = new NpgsqlConnection("Host=localhost;Username=postgres;Password=Divesh@007;Database=OfflineExamPrac;"))
            {

            try
            {
                conn.Open();

                using var cmd = new NpgsqlCommand("select c_itemid ,c_itemname,c_itemimage,c_initialstock,c_availablestock,c_itemcost,c_itemimage,c_catid from t_item where c_itemid=@id", conn);

                cmd.Parameters.AddWithValue("@id", id);

                 using var reader = cmd.ExecuteReader();

                while (reader.Read())
                {

                    item.c_itemid = Convert.ToInt32(reader["c_itemid"]);
                    item.c_catid = Convert.ToInt32(reader["c_catid"]);
                    item.c_initialstock = Convert.ToInt32(reader["c_initialstock"]);
                    item.c_availablestock = Convert.ToInt32(reader["c_availablestock"]);
                    item.c_itemcost = Convert.ToInt32(reader["c_itemcost"]);
                    item.c_itemimage = reader["c_itemimage"].ToString();
                    item.c_itemname = reader["c_itemname"].ToString();


                };


            }
            catch (Exception e)
            {

            }
            finally
            {
                conn.Close();
            }
            }
            return item;


        }

        public void Delete(tblItem product)
        {
            try
            {
                _conn.Open();
                var cmd = new NpgsqlCommand("DELETE FROM t_item WHERE c_itemid = @id", _conn);
                cmd.Parameters.AddWithValue("id", product.c_itemid);
                cmd.ExecuteNonQuery();
            }catch(Exception e){
                Console.WriteLine(e.Message);
            }
            finally
            {
                _conn.Close();
            }
        }

        public List<tblCategory> GetAllcategories()
        {

            var categories = new List<tblCategory>();
            using (var conn = new NpgsqlConnection("Host=localhost;Username=postgres;Password=Divesh@007;Database=OfflineExamPrac;"))
            {
            try
            {
                conn.Open();

                using var cmd = new NpgsqlCommand("select c_categoryname,c_categoryid from t_category", conn);

                var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    var category = new tblCategory
                    {
                        c_categoryid = Convert.ToInt32(reader["c_categoryid"]),

                        c_categoryname = reader["c_categoryname"].ToString(),

                    };
                    categories.Add(category);
                }

            }
            catch (Exception e)
            {

            }
            finally
            {
                conn.Close();
            }
            }
            return categories;

        }

         public List<tblItem> GetAllItemsCustomer()
        {

            var items = new List<tblItem>();
            using (var conn = new NpgsqlConnection("Host=localhost;Username=postgres;Password=Divesh@007;Database=OfflineExamPrac;"))
            {
            try
            {
                conn.Open();

                using var cmd = new NpgsqlCommand("select c_itemid,c_itemname,c_itemimage,c_itemcost from t_item", conn);

                var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    var item = new tblItem
                    {
                        c_itemid = Convert.ToInt32(reader["c_itemid"]),
                    
                        c_itemcost = Convert.ToInt32(reader["c_itemcost"]),
                        c_itemimage = reader["c_itemimage"].ToString(),
                        c_itemname = reader["c_itemname"].ToString(),
                       


                    };
                    items.Add(item);
                }

            }
            catch (Exception e)
            {

            }
            finally
            {
                conn.Close();
            }
            }
            return items;


        }

         public tblItem GetOneItemCustomer(int id)
        {
            var item = new tblItem();
            using (var conn = new NpgsqlConnection("Host=localhost;Username=postgres;Password=Divesh@007;Database=OfflineExamPrac;"))
            {
            try
            {
                conn.Open();

                using var cmd = new NpgsqlCommand("select c_itemid ,c_itemname,c_itemcost from t_item where c_itemid=@id", conn);

                cmd.Parameters.AddWithValue("@id", id);

                 using var reader = cmd.ExecuteReader();

                while (reader.Read())
                {

                    item.c_itemid = Convert.ToInt32(reader["c_itemid"]);
                   
                    item.c_itemcost = Convert.ToInt32(reader["c_itemcost"]);
                   
                    item.c_itemname = reader["c_itemname"].ToString();


                };


            }
            catch (Exception e)
            {

            }
            finally
            {
                conn.Close();
            }
            }
            return item;


        }

        public void UpdateItemCustomer(tblItem item)
{
    try
    {
        _conn.Open();

        using var cmd = new NpgsqlCommand("UPDATE t_item SET c_quantity = @quantity, c_total = @total, c_availablestock = c_availablestock - @quantity WHERE c_itemid = @id", _conn);
        cmd.Parameters.AddWithValue("@id", item.c_itemid);
        cmd.Parameters.AddWithValue("@quantity", item.c_quantity);  
        cmd.Parameters.AddWithValue("@total", item.c_total);
        
        
        cmd.ExecuteNonQuery();

        _conn.Close();
    }
    catch (Exception e)
    {
        Console.WriteLine(e.Message);
    }
    finally
    {
        _conn.Close();
    }
}



    }
}